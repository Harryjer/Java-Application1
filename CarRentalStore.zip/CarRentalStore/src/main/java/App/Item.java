/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

/**
 *
 * @author abc1
 */
public class Item implements Comparable<Item>{
    private int carID;
    private String carModel;
    private float rentPrice;
    private float milage;
    private String status;

    public int getCarID() {
        return carID;
    }

    public void setCarID(int carID) {
        this.carID = carID;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public float getRentPrice() {
        return rentPrice;
    }

    public void setRentPrice(float rentPrice) {
        this.rentPrice = rentPrice;
    }

    public float getMilage() {
        return milage;
    }

    public void setMilage(float milage) {
        this.milage = milage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Item(int carID, String carModel, float rentPrice, float milage, String status) {
        this.carID = carID;
        this.carModel = carModel;
        this.rentPrice = rentPrice;
        this.milage = milage;
        this.status = status;
    }

    @Override
    public String toString() {
        return carModel+", Price: "+ rentPrice+", Milage: "+ milage+", "+status;
    }

    @Override
    public boolean equals(Object obj) {
       
        Item i = (Item)obj;
        if(this.carID==i.carID){
            return true;
        }
        else
        return false;
    }

    @Override
    public int compareTo(Item o) {
        
        if(rentPrice>o.getRentPrice()){
            return -1;
        }
        else if(rentPrice<o.getRentPrice()){
            return 1;
            
        }
        else 
            return 0;
    }
    
}
