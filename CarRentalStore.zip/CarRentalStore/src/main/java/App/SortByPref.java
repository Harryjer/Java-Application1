/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;

import java.util.Comparator;

/**
 *
 * @author abc1
 */
public class SortByPref implements Comparator<Item>{

    @Override
    public int compare(Item o1, Item o2) {
        if(o1.getMilage()>o2.getMilage()){
            return 1;
        }
        else if(o1.getMilage()<o2.getMilage()){
            return -1;
        }
        else
            return 0;
    }
    
}
